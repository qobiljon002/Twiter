import React, { useState, useEffect } from 'react';

import { AuthPage } from './components';
import { HomePage } from './components/HomePage/pages/HomePage';

import styles from './App.module.scss'

function App() {
  const [homeIsOpen, setHomeIsOpen] = useState<boolean>(false)
  useEffect(() => {
    const rootElem = document.querySelector("#twitter");
    if (rootElem)
      rootElem.addEventListener("wheel", (e: any): void => {
        if (e.ctrlKey) {
          e.preventDefault();
        }
      });
  });
  return (
    <>
      {!homeIsOpen && localStorage.length < 3 ? <AuthPage setHomeIsOpen={setHomeIsOpen}/> : <HomePage setHomeIsOpen={setHomeIsOpen}/>}
    </>
  );
}

export default App;
