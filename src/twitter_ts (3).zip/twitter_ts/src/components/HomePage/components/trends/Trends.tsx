import React from 'react'
import styles  from './trends.module.css'
import SearchIcon from '../../assets/icons/Search.svg'
import EMProfileIcon from '../../assets/icons/EMProfileIcon.jpg'
import Confirmed from '../../assets/icons/Confirmed.svg'

const Dates = [
  {
    imgName: EMProfileIcon,
    userName: "Elon Musk",
    nickName: "@elonmusk",
    confirmed: Confirmed
  },

    {
    imgName: EMProfileIcon,
    userName: "Elon Musk",
    nickName: "@elonmusk",
    confirmed: Confirmed
  },
  {
    imgName: EMProfileIcon,
    userName: "Elon Musk",
    nickName: "@elonmusk",
    confirmed: Confirmed
  },
  {
    imgName: EMProfileIcon,
    userName: "Elon Musk",
    nickName: "@elonmusk",
    confirmed: Confirmed
  },
  {
    imgName: EMProfileIcon,
    userName: "Elon Musk",
    nickName: "@elonmusk",
    confirmed: Confirmed
  },
    
] 

const Trends = () => {
  return (
    <section className={styles.container}>
          <div className={styles.search}>
            <img src={SearchIcon} alt="/" />
            <input placeholder='Search Tweet' type="text" />
          </div>
          <div className={styles.trends__title}>
            <h1>Trends for you</h1>
          </div>

          <div className={styles.popularAccs}>
            <div className={styles.popularAccs__title}>
              <h2>Who to follow</h2>
            </div>
            {
              Dates.map((item, index) => (
                <div className={styles.Cards} key={index}>
                  <img className={styles.profileIcon} src={item.imgName} alt="/" />
                  <div>
                    <h4>{item.userName}<span><img src={item.confirmed} alt="/" /></span></h4>
                    <p>{item.nickName}</p>
                  </div>
                  <button className={styles.buttonFollow}>Follow</button>
                </div>
              ))  
            }
          </div>
    </section>
  )
}

export default Trends