import React, {useState} from 'react'
import styles from './MoreItemModal.module.css'
import Arrow from '../../../assets/icons/Arrow.svg'
import more from '../../../assets/icons/More.svg'

const  Dates = [
    {
        imgUrl: '',
        title: "Moments"
    },
    {
        imgUrl: '',
        title: "Newsletters"
    },
    {
        imgUrl: '',
        title: "Analytics"
    }

]

export interface ItemModal {
    moreItemModal : string | any,
    setMoreItemModal: Function
}
const MoreItemModel = ({moreItemModal, setMoreItemModal}: ItemModal) => {
    const [firstSelect, setFirstSelect] = useState(false)
    const [secondSelect, setSecondSelect] = useState(false)
    const [thirdSelect, setThirtSelect] = useState(false)
 
    const select = () =>  {
        setFirstSelect(true)
        console.log(firstSelect)
    } 
  if(!moreItemModal) return null;
  return (
    <div>
        <div  className={styles.modal__moreItem}>
            <div className={styles.title}>
                <h1> <img src={more}alt="/"/> <span>Topics</span></h1>                
                <div className={styles.line}></div>
            </div>  
           <div className={styles.selects}>
            <div className={styles.first__select}>
                <div onClick={select} className={styles.select__title}>
                    <h1>Creator Studio</h1>
                    <img onClick={() => setFirstSelect(false)} src={Arrow} alt="/"/>
                </div>            
                <div className={firstSelect ? styles.show : styles.hidden}>
                    <ul onClick={() => setFirstSelect(false)} className={styles.lists__box}>
                        {
                            Dates.map((item, index) => (
                                <li className={styles.list} key={index}>
                                    {/* <img src={item.imgUrl} alt="/" /> */}
                                    <span>{item.title}</span>
                                </li>
                            ) )
                        }  
                    </ul>
                </div>
            </div>

            <div className={styles.second__select}>
                <div onClick={() => setSecondSelect(true)} className={styles.select__title}>
                    <h1>Professional Tools</h1>
                    <img onClick={() => setSecondSelect(false)} src={Arrow} alt="/"/>
                </div>            
                <div className={secondSelect ? styles.show : styles.hidden}>
                    <ul onClick={() => setSecondSelect(false)} className={styles.lists__box}>
                        {
                            Dates.map((item, index) => (
                                <li className={styles.list} key={index}>
                                    {/* <img src={item.imgUrl} alt="/" /> */}
                                    <span>{item.title}</span>
                                </li>
                            ) )
                        }  
                    </ul>
                </div>
            </div>
            
            <div className={styles.second__select}>
                <div onClick={() => setThirtSelect(true)} className={styles.select__title}>
                    <h1>Settings and Support</h1>
                    <img onClick={() =>setThirtSelect(false)} src={Arrow} alt="/"/>
                </div>            
                <div className={thirdSelect ? styles.show : styles.hidden}>
                    <ul onClick={() => setThirtSelect(false)} className={styles.lists__box}>
                        {
                            Dates.map((item, index) => (
                                <li className={styles.list} key={index}>
                                    {/* <img src={item.imgUrl} alt="/" /> */}
                                    <span>{item.title}</span>
                                </li>
                            ) )
                        }  
                    </ul>
                </div>
            </div>
           </div>
        </div>
        <div  onClick={()=>{
            setMoreItemModal(false)
        }} className={styles.modalBg}></div>
    </div>
  )
}

export default MoreItemModel            
