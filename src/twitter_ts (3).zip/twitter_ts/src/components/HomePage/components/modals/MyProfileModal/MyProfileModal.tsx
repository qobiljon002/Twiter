import React, { useState } from "react";
import styles from "./MyProfileModal.module.css";

export interface Profile {
  profileModal: string | any;
  setProfileModal: Function;
  setHomeIsOpen: Function;
  removeCookie: Function;
  about: any
}

const MyProfileModal = ({
  profileModal,
  setProfileModal,
  setHomeIsOpen,
  removeCookie,
  about
}: Profile) => {
  if (!profileModal) return null;
  
  return (
    <div
      onClick={() => {
        setProfileModal(false);
      }}
    >
      <div className={styles.modal}>
        <div className={styles.row__first}></div>
        <div className={styles.row__second}>
          <h4>Add an axisiting account</h4>
        </div>
        <div
          className={styles.row__third}
          onClick={() => {
            localStorage.clear();
            setHomeIsOpen(true);
            window.location.reload();
            if (about.emailOrPhone && about.user && about.pass) {
              console.log()
            } else {
              removeCookie('message')
            }
          }}
        >
          <h4>Log out @{localStorage.getItem("user")?.toLocaleLowerCase()}</h4>
        </div>
        <div className={styles.row__fourth}>
          <div className={styles.arrow_buttom}></div>
        </div>
      </div>
      <div
        className={styles.modalBg}
        onClick={() => {
          setProfileModal(false);
        }}
      ></div>
    </div>
  );
};

export default MyProfileModal;
