import React from "react";

import styles from "./Emoji.module.scss";

export interface Emoji {
  setEmoji: Function;
  setMessage: Function
  message : any
}

const EmojiList = [
  "😀",
  "😃",
  "😄",
  "😁",
  "😆",
  "🤫",
  "😅",
  "😂",
  "🤣",
  "😶",
  "🤗",
  "😊",
  "😇",
  "🙂",
  "🙃",
  "😉",
  "😌",
  "😍",
  "🥰",
  "😘",
  "😗",
  "😙",
  "😚",
  "😋",
  "😛",
  "😝",
  "😜",
  "🤪",
  "🤨",
  "🧐",
  "🤓",
  "😎",
  "💩",
  "🤩",
  "🥳",
  "😏",
  "😒",
  "😞",
  "😔",
  "😟",
  "😕",
  "😣",
  "😭",
  "😤",
  "😠",
  "😡",
  "🤯",
  "😳",
  "🥵",
  "🥶",
  "😶",
  "😱",
  "😨",
  "😰",
  "😥",
  "😓",
  "🤗",
  "🤔",
  "🤭",
  "🤥",
  "🤫",
  "😐",
  "🤑",
];

export const Emoji: React.FC<Emoji> = ({ setEmoji, setMessage, message }: Emoji) => {
  const emojiHandler = (e: any) => {
    console.dir(e.target.textContent);
    setMessage(`${message}${e.target.textContent}`)
  };
  return (
    <>
      <div className={styles.Emoji}>
        <div className={styles.emojies}>
          <h2>Emoji & face</h2>
          <ul className={styles.emojiesList}>
            {EmojiList.map((emoji: any) => {
              return (
                <li>
                  <p onClick={emojiHandler}>{emoji}</p>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
      <div
        className={styles.bg}
        onClick={() => {
          setEmoji(false);
        }}
      />
    </>
  );
};
