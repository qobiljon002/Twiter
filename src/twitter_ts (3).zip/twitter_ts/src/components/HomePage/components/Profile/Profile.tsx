import classNames from "classnames";
import React, { useEffect } from "react";
import Tweet from "../Tweet/Tweet";

import { Link } from "react-router-dom";

import styles from "./Profile.module.scss";

export interface Data {
  about: any;
  data: any;
  setAbout: Function;
  deleteTweetHandler: Function;
  user: any;
  profile: any;
  setProfile: Function;
}

const Map = [
  {
    name: "Tweets",
  },
  {
    name: "Media",
  },
  {
    name: "Likes",
  },
  {
    name: "Replies",
  },
];

export const Profile: React.FC<Data> = ({
  about,
  data,
  setAbout,
  deleteTweetHandler,
  user,
  profile,
  setProfile
}: Data) => {
  const [filter, setFilter] = React.useState<string>("Tweets");

  const name = localStorage.getItem("user");
  let Name = "";
  if (name) {
    const nameFirst = name[0].toUpperCase();
    const lastName = name.slice(1);
    const fullName = `${nameFirst}${lastName}`;
    Name = fullName;
  }

  const selector = (item: any) => {
    if (filter === item.name) {
      return true;
    }
  };

  return (
    <div className={styles.profile}>
      <div className={styles.content__title}>
        <h1>{Name}</h1>
        <p>{about && about.message ? about.message.length : null} Tweets</p>
      </div>
      <div className={styles.content__header}></div>
      <div className={styles.content__user}>
        <div className={styles.user__top}>
          {user?.map((e: any) => {
            console.log(e);
            return <img src={e.img[0]} alt={e.img[0]} />;
          })}
          <button type="button">Edit profile</button>
        </div>
        <div className={styles.user__btm}>
          <h2>{Name}</h2>
          <p>@{localStorage.getItem("user")?.toLocaleLowerCase()}</p>
        </div>
        <div className={styles.tweets}>
          <ul>
            {Map.map((item: any) => {
              return (
                <li
                  key={item.name}
                  onClick={() => {
                    setFilter(item.name);
                  }}
                  className={styles.tweets__list}
                >
                  <p className={styles.tweets__tweet}>{item.name}</p>
                  <p
                    className={classNames(selector(item) ? styles.line : "")}
                  />
                </li>
              );
            })}
          </ul>
        </div>
        {about && about.message ? (
          about.message.map((e: any) => {
            return (
              <Tweet
                id={e.id}
                deleteTweetHandler={deleteTweetHandler}
                setAbout={setAbout}
                about={about}
                key={e.id}
                e={e.text}
                img={e.img}
                data={data}
              />
            );
          })
        ) : (
          <div className={styles.no__tweet}>
            <h2>You don't have any tweets, tweet now!!</h2>
            <a href="/">Tweet</a>
          </div>
        )}
      </div>
    </div>
  );
};
