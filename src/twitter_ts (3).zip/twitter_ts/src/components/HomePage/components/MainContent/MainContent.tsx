import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
// @ts-ignore
import CircularProgress from "@mui/material/CircularProgress";
import Tweet from "../Tweet/Tweet";
import styles from "./MainContent.module.css";
import navImg from "../../assets/icons/NavImg.svg";
import planetIcon from "../../assets/icons/planetIcon.svg";
import close from "../../assets/icons/icon.png";
import Media from "../../assets/icons/Media.svg";
import GIF from "../../assets/icons/Gif.svg";
import Poll from "../../assets/icons/Poll.svg";
import Emoji from "../../assets/icons/Emoji.svg";
import { Emoji as Stiker } from "../modals/Emojies/Emoji";
import Schedule from "../../assets/icons/Schedule.svg";
import Add from "../../assets/icons/Add.svg";
import classNames from "classnames";
import { useCookies } from "react-cookie";
import { Link, useFormAction } from "react-router-dom";

export interface Data {
  about: any;
  setAbout: Function;
  data: any;
  setData: Function;
  setImageURLs: Function;
  imageURLs: any;
  deleteTweetHandler: Function;
  user: any;
  profile: any;
  setProfile: Function;
}

function MainContent({
  about,
  setAbout,
  data,
  setImageURLs,
  imageURLs,
  setData,
  deleteTweetHandler,
  profile,
  setProfile,
  user,
}: Data) {
  const [value, setValue] = useState<number>(0);
  const [over, setOver] = useState<boolean>(false);
  const [images, setImages] = useState<any>([]);
  const [emoji, setEmoji] = useState<boolean>(false);
  const [inputValue, setInputValue] = useState<any>("");

  const fileRef = useRef<any>(null);
  const messageRef = useRef<any>(null);
  const tweetRef = useRef<any>(null);
  const lengthRef = useRef<any>(null);

  useEffect(() => {
    if (data) {
      if (about) {
        if (about.message) {
          about.message.unshift(...data);
        }
      }
    }
    if (about.message && data) {
      data.unshift(...about.message);
    }
  }, [about && data]);

  useEffect(() => {
    if (images.length < 1) return;
    const newImageURL: any = [];
    images.forEach((image: any) => {
      newImageURL.push(URL.createObjectURL(image));
    });
    setImageURLs(newImageURL);
  }, [images]);

  const onImgChange = (e: any) => {
    setImages([...e.target.files]);
    console.log(images);
  };

  const onOver = (): void => {
    setOver(true);
  };

  const onLeave = (): void => {
    setOver(false);
  };

  const messageSendHandler = (e: any): void => {
    setInputValue(e.target.value);
    if (inputValue === "" || undefined) {
      tweetRef.current.disabled = true;
    } else {
      if (
        inputValue !== undefined ||
        ("" && imageURLs[0] === undefined) ||
        null
      ) {
        tweetRef.current.disabled = false;
        setValue(inputValue.length);
        if (value > 240) {
          tweetRef.current.disabled = true;
        }
        if (fileRef.current) {
          fileRef.current.onchange = (e: any) => {
            setImages([...e.target.files]);
            const newImageURL: any = [];
            images.forEach((image: any) => {
              newImageURL.push(URL.createObjectURL(image));
            });
            setImageURLs(newImageURL);
            tweetRef.current.onclick = () => {
              if (data) {
                data.unshift({
                  img: imageURLs[0],
                  text: inputValue ? inputValue : null,
                  id: Math.random(),
                });
              }
              setInputValue(null);
              tweetRef.current.disabled = true;
              setValue(0);
              setAbout("message", data, { path: "/" });
              setImageURLs([undefined]);
            };
          };
        }
        tweetRef.current.onclick = () => {
          message();
          console.log(data);
        };
      }
    }
  };

  const message = () => {
    if (data) {
      data.unshift({
        img: imageURLs[0],
        text: inputValue ? inputValue : null,
        id: Math.random(),
      });
    }

    setInputValue("");
    tweetRef.current.disabled = true;
    setValue(0);
    setAbout("message", data, { path: "/" });
    setImageURLs([null]);
  };

  const circleRef = useRef();
  const [progressState, setProgressState] = useState<any>(1);
  const [input, setInput] = useState<any>();
  const inputHandler = (e: any) => {
    setInput(e.target.value);
  };

  return (
    <section className={styles.container}>
      <div className={styles.content__title}>
        <h1>Home</h1>
        <img src={navImg} alt="/" />
      </div>
      <div className={styles.liaveTweet}>
        <div className={styles.liaveTweet__box}>
          <div>
            {user?.map((e: any) => {
              return <img src={e.img[0]} alt={e.img[0]} />;
            })}
            <textarea
              className={styles.liaveTweet__input}
              onChange={messageSendHandler}
              value={inputValue}
              // ref={messageRef}
              placeholder="What's happening"
            />
            <p
              ref={lengthRef}
              className={classNames(
                value < 240 ? styles.primary : styles.warning
              )}
            >
              {" "}
              {value} / 240
            </p>
          </div>
          <div className={styles.someFile}>
            {imageURLs && imageURLs[0]
              ? imageURLs.map((imageSrc: any) => (
                  <>
                    <img
                      key={Math.random() * 2e8}
                      className={styles.fileUpload}
                      src={imageSrc}
                    />
                    <button
                      onMouseOver={onOver}
                      onClick={() => {
                        setImageURLs([undefined]);
                      }}
                      onMouseLeave={onLeave}
                      className={styles.removeBtn}
                    >
                      <img src={close} alt="" />
                    </button>
                    {over ? <p className={styles.overParam}>remove</p> : null}
                  </>
                ))
              : null}
          </div>
          <div className={styles.canAnyOne}>
            <img src={planetIcon} alt="/" />
            <h4>Everyone can reply</h4>
          </div>
        </div>
        <div className={styles.liaveTweet__bottom}>
          <div className={styles.h__line}></div>
          <div className={styles.adds}>
            <div className={styles.file}>
              <img src={Media} alt="/" />
              <input
                type="file"
                ref={fileRef}
                multiple
                accept="image/*"
                onChange={onImgChange}
              />
            </div>
            <img src={GIF} alt="/" />
            <img src={Poll} alt="/" />
            <img
              src={Emoji}
              alt="/"
              onClick={() => {
                setEmoji(!emoji);
                console.log("seee");
              }}
            />
            <img src={Schedule} alt="/" />
          </div>
          <div>
            <div className={styles.circle}></div>
            <div className={styles.v_line}></div>
            <img src={Add} alt="/" />
            <button ref={tweetRef} disabled className={styles.tweetAdd__btn}>
              Tweet
            </button>
            <textarea cols={20} rows={5} onChange={inputHandler}/>
            <div className="progress">
            {progressState === 1 ? (
                <>
                  <span className={styles.charLeft}>
                    {/* @ts-ignore */}
                    {input.length < 260 ? null : setProgressState(2)}
                  </span>

                  <CircularProgress
                    size={30}
                    ref={circleRef}
                    className="charProgress"
                    variant="determinate"
                    thickness={1}
                    // @ts-ignore
                    value={input ? input.length / 2.8 : null}
                  />
                </>
              ) : (
                <div>
                  <span className={styles.charLeft}>
                    {/* @ts-ignore */}
                    {input.length < 260
                    // @ts-ignore
                      ? setProgressState(1) && null
                      : 280 - input.length}
                  </span>
                  <CircularProgress
                    size={30}
                    ref={circleRef}
                    color="warning"
                    className="charProgress"
                    variant="determinate"
                    thickness={1}
                    value={input.length / 2.8}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      {emoji && (
        <Stiker
          message={inputValue}
          setMessage={setInputValue}
          setEmoji={setEmoji}
        />
      )}
      {about &&
      about.message &&
      about.message.length !== 0 &&
      about.message.text !== "" ? (
        about.message.map((e: any) => {
          return (
            <Tweet
              deleteTweetHandler={deleteTweetHandler}
              data={data}
              e={e.text}
              img={e.img}
              setAbout={setAbout}
              id={e.id}
              key={e.id}
              about={about}
            />
          );
        })
      ) : (
        <div className={styles.no__tweet}>
          <h2>You don't have any tweets</h2>
          <Link to="/">Tweet now</Link>
        </div>
      )}
    </section>
  );
}

export default MainContent;
