import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import classNames from "classnames";
import { Link } from "react-router-dom";
import styles from "./navbar.module.css";
import logo from "../../assets/icons/twitter-icon.svg";
import home from "../../assets/icons/Home.svg";
import explore from "../../assets/icons/Explore.svg";
import notification from "../../assets/icons/Notifications.svg";
import messages from "../../assets/icons/Messages.svg";
import bookmarks from "../../assets/icons/Bookmarks.svg";
import lists from "../../assets/icons/Lists.svg";
import profile from "../../assets/icons/Profile.svg";
import more from "../../assets/icons/More.svg";
import accIcon from "../../assets/icons/acc-icon.png";
import feather from "../../assets/icons/feather.svg";
import homeBold from "../../assets/icons/Home-bold.svg";
import exploreBold from "../../assets/icons/Explore-bold.svg";
import notificationBold from "../../assets/icons/Notifications-bold.svg";
import messagesBold from "../../assets/icons/Messages-bold.svg";
import bookmarksBold from "../../assets/icons/Bookmarks-bold.svg";
import listsBold from "../../assets/icons/Lists-bold.svg";
import profileBold from "../../assets/icons/Profile-bold.svg";
import MyProfileModal from "../modals/MyProfileModal/MyProfileModal";
import MoreItemModel from "../modals/MoreItemModal/MoreItemModel";
const NavLinks = [
  {
    title: "Home",
    url: "/",
    img: home,
    boldImg: homeBold,
  },
  {
    title: "Explore",
    url: "/",
    img: explore,
    boldImg: exploreBold,
  },
  {
    title: "Notification",
    url: "/",
    img: notification,
    boldImg: notificationBold,
  },
  {
    title: "Messages",
    url: "/",
    img: messages,
    boldImg: messagesBold,
  },
  {
    title: "Bookmarks",
    url: "/",
    img: bookmarks,
    boldImg: bookmarksBold,
  },
  {
    title: "Lists",
    url: "/",
    img: lists,
    boldImg: listsBold,
  },
  {
    title: "Profile",
    url: `${localStorage.getItem("user")?.toLocaleLowerCase()}`,
    img: profile,
    boldImg: profileBold,
  },
  {
    title: "More",
    url: "/",
    img: more,
    boldImg: more,
  },
];

export interface Auth {
  setHomeIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  removeCookie: Function
  about : any
  data: any
  user: any
}

const Navbar = ({ setHomeIsOpen, removeCookie, about, data, user }: Auth) => {
  const [filter, setFilter] = useState<string>(`${document.title}`);
  const [profileModal, setProfileModal] = useState<boolean>(false);
  const [moreItemModal, setMoreItemModal] = useState<boolean>(false);
  const boldClass = (item: any) => {
    if (filter === item.title) {
      if (item.title === "More") {
        return false;
      }
      return true;
    }
  };

  const name = localStorage.getItem("user");
  let Name = ''
  if (name) {
    const nameFirst = name[0].toUpperCase();
    const lastName = name.slice(1);
    const fullName = `${nameFirst}${lastName}`
    Name = fullName
  }

  useEffect(() => {
    NavLinks.map((e) => {
      document.title = `${filter}`;
      if (filter === "More") {
        console.log('ewfef');
      } else {
        return;
      }
    });
  });

  return (
    <div>
      <div className={styles.navigation}>
        <div className={styles.logo}>
          <img src={logo} alt="/" />
        </div>
        <div className={styles.nav__menu}>
          <ul className={styles.nav__list}>
            {NavLinks.map((item, index) => {
              return (
              <li
                onClick={() => {
                  setFilter(item.title);
                  if (item.title === "More") {
                    setMoreItemModal(true);
                  }
                }}
                className={classNames(
                  boldClass(item)
                    ? [styles.nav__item, styles.activeItem]
                    : styles.nav__item
                )}
                key={index}
              >
                <Link key={item.boldImg + item} to={item.url}>
                  <div>
                    <img
                      src={filter === item.title ? item.boldImg : item.img}
                      alt="/"
                    />
                  </div>
                  <span>{item.title}</span>
                </Link>
              </li>
              )
            })}
          </ul>
          <MoreItemModel
            moreItemModal={moreItemModal}
            setMoreItemModal={setMoreItemModal}
          />
          <div className={styles.twBtn}>
            <button>Tweet</button>
            <div>
              <span>+</span>
              <img className={styles.feactherImg} src={feather} alt="/" />
            </div>
          </div>
          <MyProfileModal
            setHomeIsOpen={setHomeIsOpen}
            profileModal={profileModal}
            about={about}
            removeCookie={removeCookie}
            // closeProfileModal={closeProfileModal}
            setProfileModal={setProfileModal}
          />
          <div
            onClick={() => setProfileModal(true)}
            className={styles.myAccount}
          >
            <div className={styles.myAcc__desc}>
              <div className={styles.profile__icon}>
                {user?.map((e : any) => {
                  return <img key={e.img[0]} src={e.img[0]} width={48} alt={e.img[0]} />
                })}
              </div>
              <div className={styles.myAcc__title}>
                <h4>{Name}</h4>
                <p>@{localStorage.getItem("user")?.toLocaleLowerCase()}</p>
              </div>
            </div>
            <div className={styles.myAcc__more}>
              <span>.</span>
              <span>.</span>
              <span>.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
