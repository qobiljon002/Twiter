import React from "react";
import styles from "./tweet.module.css";
import Reply from "../../assets/icons/Reply.svg";
import Retweet from "../../assets/icons/Retweet.svg";
import Like from "../../assets/icons/Like.svg";
import likePink from "../../assets/icons/like.png";
import classNames from "classnames";

export interface Tweet {
  e: string;
  data: any;
  about: any;
  img : string;
  setAbout : Function;
  id : any
  deleteTweetHandler: Function
}

const Tweet: React.FC<Tweet> = ({ setAbout, data, id, e, img ,about, deleteTweetHandler }: Tweet) => {
  const date = new Date();

  const [like, setLike] = React.useState<boolean>(false);

  const name = localStorage.getItem("user");
  let Name = "";
  if (name) {
    const nameFirst = name[0].toUpperCase();
    const lastName = name.slice(1);
    const fullName = `${nameFirst}${lastName}`;
    Name = fullName;
  }

  const likePutHandler = (e: any): void => {
    setLike(!like);
  };
  return (
    <>
      {e ? (
        <>
          <div className={styles.tweetCartSmall}>
            <div className={styles.tweetContent}>
              <img
                className={styles.scProfileIcon}
                src="https://www.blexar.com/avatar.png"
                width={48}
                height={48}
                alt="/"
              />
              <div className={styles.tweetContent__texts}>
                <div>
                  <h4>{Name}</h4>
                  <p>
                    @{localStorage.getItem("user")?.toLocaleLowerCase()}{" "}
                    <span> . </span> {date.getDate()} November
                  </p>
                </div>
                <p key={Math.random() * 100000}>{e}</p>
                { img ? <img src={img} alt={`${img.length}`} className={styles.someFile} width={550}/> : null}
              </div>
            </div>
            <div className={styles.SmallCartFooter}>
              <img src={Reply} alt="/" />
              <img src={Retweet} alt="/" />
              <img
                onClick={likePutHandler}
                src={!like ? Like : likePink}
                alt="/"
                className={classNames(!like ? styles.like__ : styles.like__pink)}
              />
              <img
                src="https://cdn-icons-png.flaticon.com/512/3208/3208592.png"
                width={20}
                height={20}
                onClick={() => {
                  deleteTweetHandler(id)
                  console.log(id);
                }}
                alt="/"
              />
            </div>
          </div>
        </>
      ) : null}
    </>
  );
};

export default Tweet;
