import React, { useRef, useEffect, useState } from "react";
import { useCookies } from "react-cookie/";

import { Routes, Route } from "react-router-dom";

import axios from "axios";

import styles from "./HomePage.module.scss";
import MainContent from "../components/MainContent/MainContent";
import Navbar from "../components/navigation/Navbar";
import Trends from "../components/trends/Trends";
import { Profile } from "../components/Profile";
import { AuthPage } from "../../AuthPage";

export interface Auth {
  setHomeIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

export const HomePage = ({ setHomeIsOpen }: Auth) => {
  const [about, setAbout, removeCookie] = useCookies(["message"]);
  const [data, setData] = useState<
    | {
        id: string;
        userID: string;
        text: string;
        hashtags: [];
        imgs: string[];
        videos: string[];
        newTweet: string[];
        comments: string[];
        likes: string[];
        newImg: string[];
      }[]
    | null
  >(null);
  const [user, setUser] = useState<{
    img: string[];
    name: string[]
    email : string[]
    pass: string[]
  } | null>(null);
  const [profile, setProfile] = useCookies(["profile"]);

  const [imageURLs, setImageURLs] = useState<any>([]);

  useEffect(() => {
    axios.get("http://localhost:3001/").then((response) => {
      setData(response.data.tweets);
      setUser(response.data.user);
    });
  }, []);

  const deleteTweetHandler = (id: any): void => {
    if (data) {
      data.filter((tweet: any) => tweet !== id);
      console.log(about);
      if (data) {
        data.push(...about.message);
      }
      console.log(id);
      console.log(about);
    }
  };

  return (
    <>
      <div className={styles.container}>
        <Navbar
          data={data}
          user={user}
          about={about}
          removeCookie={removeCookie}
          setHomeIsOpen={setHomeIsOpen}
        />
        <Routes>
          <Route
            path="/"
            element={
              <MainContent
                about={about}
                data={data}
                imageURLs={imageURLs}
                deleteTweetHandler={deleteTweetHandler}
                setImageURLs={setImageURLs}
                setData={setData}
                setAbout={setAbout}
                profile={profile}
                setProfile={setProfile}
                user={user}
              />
            }
          />
          <Route
            path={`/${localStorage.getItem("user")?.toLocaleLowerCase()}`}
            element={
              <Profile
                user={user}
                data={data}
                deleteTweetHandler={deleteTweetHandler}
                setAbout={setAbout}
                about={about}
                setProfile={setProfile}
                profile={profile}
              />
            }
          />
          <Route
            path="*"
            element={
              <MainContent
                data={data}
                setData={setData}
                user={user}
                imageURLs={imageURLs}
                profile={profile}
                deleteTweetHandler={deleteTweetHandler}
                setImageURLs={setImageURLs}
                about={about}
                setProfile={setProfile}
                setAbout={setAbout}
              />
            }
          />
        </Routes>
        <Trends />
      </div>
    </>
  );
};
