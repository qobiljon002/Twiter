import React, { useState, useRef, useEffect } from "react";

import styles from "./AuthLogin.module.scss";
import icon from "../images/icon.png";
import bird from "../images/twitter.gif";
import iphone from "../images/iphone.png";

export interface IAuthProps {
  setOpenLogin: Function;
  setOpenModal: Function;
  setHomeIsOpen: React.Dispatch<React.SetStateAction<boolean>> | Function;
  user: string | any,
  cookiePass: string | any,
  email: string | any
}

export const AuthLogin: React.FC<IAuthProps> = ({
  setOpenLogin,
  setOpenModal,
  setHomeIsOpen,
  user,
  cookiePass,
  email
}: IAuthProps) => {
  const [pages, setPages] = useState<number>(1);
  const [close, setClose] = useState<boolean>(false);
  const [isVisible, setIsVisible] = useState<boolean>(false);

  const btnAccesRef = useRef<any>(null);
  const passRef = useRef<any>(null);

  const disableToTrue = () => {
    if (passRef.current && passRef.current.value) {
      btnAccesRef.current.disabled = false;
      btnAccesRef.current.onclick = () => {
        if (passRef.current.value === cookiePass.pass) {
          alert(`Welcome again ${user.user}`);
          setOpenLogin(false);
          setHomeIsOpen(true)
          localStorage.setItem('pass', cookiePass.pass)
          document.body.style.overflow = "";
        } else {
          alert("Can not find");
        }
      };
    } else {
      btnAccesRef.current.disabled = true;
    }
  };

  const changeTextToPass = () : void => {
    setIsVisible(!isVisible);
  };

  const onOver = () : void => {
    setClose(true);
  };

  const onLeave = () : void => {
    setClose(false);
  };

  const accSearchRef = useRef<any>(null);

  const modalCloseHandler = () : void => {
    setOpenLogin(false);
  };

  const modalOpenHandler = () : void => {
    setOpenLogin(false);
    setOpenModal(true);
  };

  const nextPage = () : void => {
    if (accSearchRef.current && accSearchRef.current.value) {
      if (accSearchRef.current.value !== user.user) {
        alert("User not found");
      } else {
        alert(`Welcome ${user.user}`);
        localStorage.setItem('user', user.user)
        localStorage.setItem('phoneOrEmail', email.email)
        setPages(2);
      }
    } else {
      alert("User not found");
    }
  };

  // Вход в Твиттер
  return (
    <>
      <div className={styles.authModal}>
        <div className={styles.top}>
          <button type="button" onClick={modalCloseHandler}>
            <img
              onMouseOver={onOver}
              onMouseLeave={onLeave}
              src={icon}
              alt=""
            />
          </button>
          {close ? <p>Закрыть</p> : null}
          <img src={bird} alt="" />
        </div>
        {pages === 1 ? (
          <>
            <div className={styles.title}>
              <h2>Вход в Твиттер</h2>
              <div className={styles.authBy}>
                <button type="button">
                  <img
                    src="https://community.cdn.kony.com/sites/default/files/icon-google.png"
                    alt="https://community.cdn.kony.com/sites/default/files/icon-google.png"
                  />{" "}
                  Регистрация с помощью Google
                </button>
                <button type="button">
                  <img
                    src={iphone}
                    alt="https://assets.stickpng.com/images/580b57fcd9996e24bc43c516.png"
                  />{" "}
                  Зарегистрироваться с Apple ID
                </button>
                <div className={styles.authByOr}>
                  <div className={styles.line} />
                  <span>ИЛИ</span>
                  <div className={styles.line} />
                </div>
                <input type="text" ref={accSearchRef} placeholder="@username" />
                <button
                  type="button"
                  className={styles.next}
                  onClick={nextPage}
                >
                  Далее
                </button>
                <div className={styles.doNotHaveAcc}>
                  <p>Не учетной записи?</p>
                  <button type="button" onClick={modalOpenHandler}>
                    Зарегистрируйтесь
                  </button>
                </div>
              </div>
            </div>
          </>
        ) : (
          <>
            <div className={styles.title}>
              <h2>Введите пароль</h2>
              <div className={styles.pass}>
                <input
                  type={!isVisible ? "password" : "text"}
                  onChange={disableToTrue}
                  ref={passRef}
                  placeholder="Password"
                />
                <img
                  onClick={changeTextToPass}
                  src="https://cdn1.iconfinder.com/data/icons/hawcons/32/699007-icon-21-eye-hidden-512.png"
                  alt=""
                />
              </div>
              <button ref={btnAccesRef} disabled={true}>
                Войти
              </button>
              <div className={styles.some}>
                <p>Не учетной записи? </p>
                <button onClick={modalOpenHandler}>Зарегистрируйтесь</button>
              </div>
            </div>
          </>
        )}
      </div>
      <div className={styles.authBg}></div>
    </>
  );
};
