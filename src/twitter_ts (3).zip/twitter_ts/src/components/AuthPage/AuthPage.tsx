import React, { useEffect, useState } from "react";
import { useCookies } from "react-cookie";

import styles from "./AuthPage.module.scss";
import bgLeft from "./images/background.png";
import bird from "./images/twitter.gif";
import iphone from "./images/iphone.png";

import { Link } from "react-router-dom";
import { AccountModal } from "./AccountModal/AccountModal";
import { AuthLogin } from "./AuthLogin/AuthLogin";

export interface Auth {
  setHomeIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

export const AuthPage: React.FC<Auth> = ({ setHomeIsOpen }: Auth) => {
  const [openModal, setOpenModal] = useState<boolean>(false);
  const [openLogin, setOpenLogin] = useState<boolean>(false);
  const [user, setUser] = useCookies(['user']);
  const [cookiePass, setCookiePass] = useCookies();
  const [email, setEmail] = useCookies(['email']);

  const modalOpenHandler = () => {
    setOpenModal(true);
    // document.body.style.overflow = "hidden";
  };

  const loginOpenHandler = () => {
    setOpenLogin(true);
    // document.body.style.overflow = "hidden";
  };

  let listOfPrivacy = [
    "О себе",
    "Справочный центр",
    "Условия предоставления услуг",
    "Политика конфиденциальности",
    "Политика в отношении файлов cookie",
    "Специальные возможности",
    "Информация о рекламе",
    "Блог",
    "Статус",
    "Работа",
    "Ресурсы бренда",
    "Реклама",
    "Маркетинг",
    "Твиттер для бизнеса",
  ];

  const date = new Date();

  const year = date.getFullYear();

  return (
    <>
      <div className={styles.authPage}>
        <div className={styles.leftSide}>
          <img className={styles.bgImg} src={bgLeft} alt={bgLeft} />
          <img className={styles.twitBird} src={bird} alt={styles} />
        </div>
        <div className={styles.rightSide}>
          <div className={styles.auth}>
            <img className={styles.rightBird} src={bird} alt={bird} />
            <div className={styles.authAbout}>
              <h2>В курсе происходящего</h2>
              <p>Присоединяйтесь к Твиттеру прямо сейчас!</p>
            </div>
            <div className={styles.authBy}>
              <button type="button">
                <img
                  src="https://community.cdn.kony.com/sites/default/files/icon-google.png"
                  alt="https://community.cdn.kony.com/sites/default/files/icon-google.png"
                />{" "}
                Регистрация с помощью Google
              </button>
              <button type="button">
                <img
                  src={iphone}
                  alt="https://assets.stickpng.com/images/580b57fcd9996e24bc43c516.png"
                />{" "}
                Зарегистрироваться с Apple ID
              </button>
              <div className={styles.authByOr}>
                <div className={styles.line} />
                <span>ИЛИ</span>
                <div className={styles.line} />
              </div>
              <Link
                className={styles.authWithPhoneOrEmail}
                onClick={modalOpenHandler}
                to="/"
              >
                Зарегистрироваться с номером те...
              </Link>
            </div>
            <div className={styles.toc}>
              Регистрируясь, вы соглашаетесь с
              <Link to="https://twitter.com/ru/tos">
                {" "}
                Условиями предоставления услуг
              </Link>{" "}
              и{" "}
              <Link to="https://twitter.com/ru/privacy">
                Политикой конфиденциальности
              </Link>
              , а также с{" "}
              <Link to="https://help.twitter.com/ru/rules-and-policies/twitter-cookies">
                {" "}
                Политикой использования файлов cookie.
              </Link>
            </div>
            <div className={styles.authHadAcc}>
              <h3>Уже зарегистрированы?</h3>
              <Link
                className={styles.login}
                onClick={loginOpenHandler}
                to="/"
              >
                Войти
              </Link>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.bottomSide}>
        <ul className={styles.politics}>
          {listOfPrivacy.map((link: string) => {
            return (
              <li key={link}>
                <Link to="/">{link}</Link>
              </li>
            );
          })}
          <p>© Twitter, Inc., {year}.</p>
        </ul>
      </div>
      {openModal && (
        <AccountModal 
        setEmailForData={setEmail}
        setCookiePass={setCookiePass}
        setHomeIsOpen={setHomeIsOpen}
        setUser={setUser}
        setOpenModal={setOpenModal}/>
      )}
      {openLogin && (
        <AuthLogin user={user} cookiePass={cookiePass} email={email} setHomeIsOpen={setHomeIsOpen} setOpenLogin={setOpenLogin} setOpenModal={setOpenModal} />
      )}
    </>
  );
};
